/**
 * @file
 * Default JS callbacks for the Menu_MiniPanels module.
 */

/**
 * If either of these callbacks need to be customized then the following must
 * be done:
 *  1. Disable the "Load default JS callbacks" option on the main settings
 *     page.
 *  2. Copy this file to a new location and set it to load as necessary, e.g.
 *     by adding it to the site's theme directory and listing it on the theme's
 *     .info file.
 *  3. Customize as necessary, see API.txt for further details of the callbacks
 *     that are available for use.
 */
(function($) {

  Drupal.behaviors.menuMiniPanelsCallbacks = {
    attach: function(context, settings) {

      // Mark target element as selected.
      MenuMiniPanels.setCallback('beforeShow', function(qTip, event, content) {
        // Forceably remove the class off all DOM elements, avoid problems
        // of it not being properly removed in certain scenarios.
        $('.qtip-hover').removeClass('qtip-hover');

        // Add the hover class to the current item.
        var $target = $(qTip.elements.target.get(0));
        if ($target !== undefined) {
          $target.addClass('qtip-hover');
        }
      });

      // Unmark target element as selected.
      MenuMiniPanels.setCallback('beforeHide', function(qTip, event, content) {
        // Remove the class off all DOM elements.
        $('.qtip-hover').removeClass('qtip-hover');
      });

      // Integrate with the core Contextual module.
      MenuMiniPanels.setCallback('onRender', function(qTip, event, content) {
        $('div.menu-minipanels div.contextual-links-wrapper', context).each(function () {
          var $wrapper = $(this);
          // Remove the popup link added from the first time the Contextual
          // module processed the links.
          $wrapper.children('a.contextual-links-trigger').detach();
          // Continue as normal.
          var $region = $wrapper.closest('.contextual-links-region');
          var $links = $wrapper.find('ul.contextual-links');
          var $trigger = $('<a class="contextual-links-trigger" href="#" />').text(Drupal.t('Configure')).click(
            function () {
              $links.stop(true, true).slideToggle(100);
              $wrapper.toggleClass('contextual-links-active');
              return false;
            }
          );
          // Attach hover behavior to trigger and ul.contextual-links.
          $trigger.add($links).hover(
            function () { $region.addClass('contextual-links-region-active'); },
            function () { $region.removeClass('contextual-links-region-active'); }
          );
          // Hide the contextual links when user clicks a link or rolls out of
          // the .contextual-links-region.
          $region.bind('mouseleave click', Drupal.contextualLinks.mouseleave);
          // Prepend the trigger.
          $wrapper.prepend($trigger);
        });
      });

    }
  };
})(jQuery);
;

/**
 * JavaScript behaviors for the front-end display of webforms.
 */

(function ($) {

Drupal.behaviors.webform = Drupal.behaviors.webform || {};

Drupal.behaviors.webform.attach = function(context) {
  // Calendar datepicker behavior.
  Drupal.webform.datepicker(context);
};

Drupal.webform = Drupal.webform || {};

Drupal.webform.datepicker = function(context) {
  $('div.webform-datepicker').each(function() {
    var $webformDatepicker = $(this);
    var $calendar = $webformDatepicker.find('input.webform-calendar');
    var startDate = $calendar[0].className.replace(/.*webform-calendar-start-(\d{4}-\d{2}-\d{2}).*/, '$1').split('-');
    var endDate = $calendar[0].className.replace(/.*webform-calendar-end-(\d{4}-\d{2}-\d{2}).*/, '$1').split('-');
    var firstDay = $calendar[0].className.replace(/.*webform-calendar-day-(\d).*/, '$1');
    // Convert date strings into actual Date objects.
    startDate = new Date(startDate[0], startDate[1] - 1, startDate[2]);
    endDate = new Date(endDate[0], endDate[1] - 1, endDate[2]);

    // Ensure that start comes before end for datepicker.
    if (startDate > endDate) {
      var laterDate = startDate;
      startDate = endDate;
      endDate = laterDate;
    }

    var startYear = startDate.getFullYear();
    var endYear = endDate.getFullYear();

    // Set up the jQuery datepicker element.
    $calendar.datepicker({
      dateFormat: 'yy-mm-dd',
      yearRange: startYear + ':' + endYear,
      firstDay: parseInt(firstDay),
      minDate: startDate,
      maxDate: endDate,
      onSelect: function(dateText, inst) {
        var date = dateText.split('-');
        $webformDatepicker.find('select.year, input.year').val(+date[0]);
        $webformDatepicker.find('select.month').val(+date[1]);
        $webformDatepicker.find('select.day').val(+date[2]);
      },
      beforeShow: function(input, inst) {
        // Get the select list values.
        var year = $webformDatepicker.find('select.year, input.year').val();
        var month = $webformDatepicker.find('select.month').val();
        var day = $webformDatepicker.find('select.day').val();

        // If empty, default to the current year/month/day in the popup.
        var today = new Date();
        year = year ? year : today.getFullYear();
        month = month ? month : today.getMonth() + 1;
        day = day ? day : today.getDate();

        // Make sure that the default year fits in the available options.
        year = (year < startYear || year > endYear) ? startYear : year;

        // jQuery UI Datepicker will read the input field and base its date off
        // of that, even though in our case the input field is a button.
        $(input).val(year + '-' + month + '-' + day);
      }
    });

    // Prevent the calendar button from submitting the form.
    $calendar.click(function(event) {
      $(this).focus();
      event.preventDefault();
    });
  });
}

})(jQuery);
;
